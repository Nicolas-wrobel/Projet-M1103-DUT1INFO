var searchData=
[
  ['clearscreen_38',['ClearScreen',['../_correc___prof_2gridmanagement_8h.html#a6a3ca153f0817e8ba91a023b886bb662',1,'gridmanagement.cpp']]],
  ['color_39',['Color',['../_correc___prof_2gridmanagement_8h.html#a7f0df05a97c053bfa8a3e5863b0a0e80',1,'gridmanagement.h']]]
];
