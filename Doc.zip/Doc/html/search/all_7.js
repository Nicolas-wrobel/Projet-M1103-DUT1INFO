var searchData=
[
  ['params_2eh_20',['params.h',['../params_8h.html',1,'']]],
  ['ppal_21',['ppal',['../game_8h.html#a0b1d64ee76933ef8f007f1208cb869a7',1,'game.cpp']]]
];
